import { create } from 'zustand'
import type { Screen, Task, User, Transaction } from './types'

interface AppState {
  // Navigation
  screen: Screen
  prevScreen: Screen | null
  setScreen: (s: Screen) => void
  goBack: () => void

  // Auth
  phone: string
  setPhone: (p: string) => void
  isAuthed: boolean
  setAuthed: (v: boolean) => void

  // User
  user: User
  setUser: (u: Partial<User>) => void

  // Tasks
  tasks: Task[]
  activeTask: Task | null
  setActiveTask: (t: Task | null) => void
  taskFilter: string
  setTaskFilter: (f: string) => void

  // Earnings
  balanceInr: number
  pendingInr: number
  transactions: Transaction[]
  addTransaction: (t: Transaction) => void

  // Toast
  toast: string
  showToast: (msg: string) => void

  // Daily progress
  todayEarnedInr: number
  dailyGoalInr: number
}

const DEMO_TASKS: Task[] = [
  {
    id: 'v-hindi-1',
    title: 'Hindi Phrase Recording',
    type: 'voice',
    language: 'Hindi',
    languageCode: 'hi',
    payInr: 170,
    estMinutes: 8,
    itemCount: 10,
    badge: 'bonus',
    isBonus: true,
    bonusMultiplier: 2,
    instructions: [
      'Find a quiet place — background noise causes rejections',
      'Tap the mic button and speak each phrase naturally',
      'Hold your phone 15–20cm from your mouth',
      'A 1-second pause between phrases is fine',
      'Speak at normal pace — don\'t rush or over-enunciate',
    ],
    phrases: [
      { native: 'नमस्ते, आप कैसे हैं?', roman: 'Namaste, aap kaise hain?' },
      { native: 'मेरा नाम प्रिया है।', roman: 'Mera naam Priya hai.' },
      { native: 'आज मौसम बहुत अच्छा है।', roman: 'Aaj mausam bahut achha hai.' },
      { native: 'क्या आप मुझे बता सकते हैं?', roman: 'Kya aap mujhe bata sakte hain?' },
      { native: 'मुझे बहुत खुशी है।', roman: 'Mujhe bahut khushi hai.' },
      { native: 'यह बाज़ार कहाँ है?', roman: 'Yeh bazaar kahan hai?' },
      { native: 'धन्यवाद, आपकी बहुत मदद हुई।', roman: 'Dhanyavaad, aapki bahut madad hui.' },
      { native: 'मैं कल वापस आऊँगी।', roman: 'Main kal waapas aaungi.' },
      { native: 'यह काम बहुत ज़रूरी है।', roman: 'Yeh kaam bahut zaroori hai.' },
      { native: 'शुभ रात्रि, अच्छी नींद लें।', roman: 'Shubh raatri, achhi neend lein.' },
    ]
  },
  {
    id: 'v-tamil-1',
    title: 'Tamil Conversation Set',
    type: 'voice',
    language: 'Tamil',
    languageCode: 'ta',
    payInr: 240,
    estMinutes: 12,
    itemCount: 6,
    badge: 'hot',
    instructions: [
      'Speak in your natural Tamil dialect — regional accent is a plus',
      'Don\'t switch to English mid-recording',
      'Quiet room required — no AC or fan noise in background',
      'Each phrase should be spoken at conversational pace',
    ],
    phrases: [
      { native: 'வணக்கம், நீங்கள் எப்படி இருக்கிறீர்கள்?', roman: 'Vanakkam, neengal eppadi irukkingal?' },
      { native: 'என் பெயர் பிரியா.', roman: 'En peyar Priya.' },
      { native: 'இன்று வானிலை மிகவும் அழகாக இருக்கிறது.', roman: 'Indru vaanam migavum azhagaaga irukkindru.' },
      { native: 'சந்தை எங்கே இருக்கிறது?', roman: 'Sandhai engey irukkindru?' },
      { native: 'மிக்க நன்றி, உங்கள் உதவி மிகவும் பயனுள்ளது.', roman: 'Mikka nandri, ungal udavi migavum payanuLLadu.' },
      { native: 'நான் நாளை திரும்பி வருவேன்.', roman: 'Naan naalai thirumbi varuven.' },
    ]
  },
  {
    id: 'vid-pov-1',
    title: 'Workplace POV Clip',
    type: 'video',
    language: 'Any',
    languageCode: 'any',
    payInr: 180,
    estMinutes: 5,
    itemCount: 1,
    badge: 'new',
    instructions: [
      'Mount or hold your phone at chest or eye height',
      'Your hands must be clearly visible throughout',
      'Keep moving — no static shots longer than 3 seconds',
      'Capture any manual task: cooking, repair, construction, driving',
      'No faces needed — hands and environment only',
      'Clip must be 25–35 seconds long',
    ]
  },
  {
    id: 'ph-street-1',
    title: 'Street Scene Photos',
    type: 'photo',
    language: 'Any',
    languageCode: 'any',
    payInr: 70,
    estMinutes: 10,
    itemCount: 10,
    instructions: [
      'Take photos outdoors in natural daylight',
      'Capture roads, markets, shops, public spaces',
      'Avoid blurry or dark images — they will be rejected',
      'No people\'s faces visible — blur or avoid them',
      'Variety preferred — different streets and angles',
    ]
  },
  {
    id: 'txt-label-1',
    title: 'Sentence Sentiment Labels',
    type: 'text',
    language: 'Any',
    languageCode: 'any',
    payInr: 45,
    estMinutes: 6,
    itemCount: 20,
    instructions: [
      'Read each sentence fully before labelling',
      'Choose the overall tone: Positive, Negative, or Neutral',
      'Don\'t overthink — go with your first impression',
      'If genuinely ambiguous, choose Neutral',
    ]
  },
  {
    id: 'v-marathi-1',
    title: 'Marathi Regional Phrases',
    type: 'voice',
    language: 'Marathi',
    languageCode: 'mr',
    payInr: 115,
    estMinutes: 7,
    itemCount: 8,
    badge: 'bonus',
    instructions: [
      'Speak in your natural Marathi dialect — Pune or Nashik preferred',
      'Don\'t switch to Hindi mid-recording',
      'Clear pronunciation at normal pace',
      'Quiet room required',
    ],
    phrases: [
      { native: 'नमस्कार, तुम्ही कसे आहात?', roman: 'Namaskar, tumhi kase aahat?' },
      { native: 'माझे नाव प्रिया आहे.', roman: 'Mazhe naav Priya aahe.' },
      { native: 'आज हवामान खूप छान आहे.', roman: 'Aaj hawamaan khoop chhan aahe.' },
      { native: 'बाजार कुठे आहे?', roman: 'Baazaar kuthe aahe?' },
      { native: 'धन्यवाद, तुमची मदत खूप उपयोगी आहे.', roman: 'Dhanyavaad, tumchi madat khoop upayogi aahe.' },
      { native: 'मी उद्या परत येईन.', roman: 'Mi udya parat yein.' },
      { native: 'हे काम खूप महत्त्वाचे आहे.', roman: 'He kaam khoop mahattwache aahe.' },
      { native: 'शुभ रात्री, चांगली झोप घ्या.', roman: 'Shubh raatri, chaangli zhop ghya.' },
    ]
  },
]

const DEMO_TRANSACTIONS: Transaction[] = [
  { id: 't1', taskTitle: 'Workplace POV Video', date: 'Today · 11:02am', amountInr: 180, status: 'approved', type: 'credit' },
  { id: 't2', taskTitle: 'Tamil Voice Set', date: 'Yesterday', amountInr: 240, status: 'approved', type: 'credit' },
  { id: 't3', taskTitle: 'Street Scene Photos ×10', date: 'Yesterday', amountInr: 70, status: 'approved', type: 'credit' },
  { id: 't4', taskTitle: 'Sentence Labels ×20', date: '2 days ago', amountInr: 45, status: 'approved', type: 'credit' },
  { id: 't5', taskTitle: 'UPI Withdrawal', date: '3 days ago', amountInr: -500, status: 'approved', type: 'withdrawal' },
]

export const useStore = create<AppState>((set, get) => ({
  screen: 'splash',
  prevScreen: null,
  setScreen: (s) => set({ prevScreen: get().screen, screen: s }),
  goBack: () => {
    const prev = get().prevScreen
    if (prev) set({ screen: prev, prevScreen: null })
  },

  phone: '',
  setPhone: (p) => set({ phone: p }),
  isAuthed: false,
  setAuthed: (v) => set({ isAuthed: v }),

  user: {
    name: 'Priya',
    phone: '+91 98765 43210',
    languages: ['Hindi', 'Tamil'],
    taskPrefs: ['voice', 'video', 'photo', 'text'],
    qualityScore: 91,
    badgeLevel: 'top',
    payoutUpi: 'priya@upi',
    joinedDate: 'January 2026',
  },
  setUser: (u) => set(s => ({ user: { ...s.user, ...u } })),

  tasks: DEMO_TASKS,
  activeTask: null,
  setActiveTask: (t) => set({ activeTask: t }),
  taskFilter: 'all',
  setTaskFilter: (f) => set({ taskFilter: f }),

  balanceInr: 1240,
  pendingInr: 170,
  transactions: DEMO_TRANSACTIONS,
  addTransaction: (t) => set(s => ({
    transactions: [t, ...s.transactions],
    pendingInr: s.pendingInr + t.amountInr,
  })),

  todayEarnedInr: 190,
  dailyGoalInr: 500,

  toast: '',
  showToast: (msg) => {
    set({ toast: msg })
    setTimeout(() => set({ toast: '' }), 2500)
  },
}))
