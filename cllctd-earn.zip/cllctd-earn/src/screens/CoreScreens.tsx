import { useStore } from '../store'

// ── SUBMISSION CONFIRM ────────────────────────────────────────────────────────
export function SubmissionConfirmScreen() {
  const { activeTask, setScreen, transactions } = useStore()
  const latest = transactions[0]
  const pay = activeTask?.payInr || latest?.amountInr || 0

  return (
    <div className="screen">
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', padding: '2rem 1.5rem', gap: '1.5rem', textAlign: 'center' }}>

        {/* Success icon */}
        <div style={{
          width: 80, height: 80, borderRadius: '50%',
          background: 'var(--green-bg)', border: '2px solid var(--green)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          fontSize: '2.2rem', animation: 'popIn 0.4s cubic-bezier(0.68,-0.55,0.265,1.55) both'
        }}>✓</div>

        <div>
          <h2 style={{ fontFamily: 'var(--font-display)', fontSize: '2rem', fontWeight: 900, color: 'var(--cream)', marginBottom: '0.5rem' }}>
            Task <em style={{ color: 'var(--green)' }}>submitted!</em>
          </h2>
          <p style={{ fontSize: '0.88rem', color: 'var(--cream-d)', lineHeight: 1.7, maxWidth: 280, margin: '0 auto' }}>
            Your submission is under review. We'll notify you when it's approved — typically within 24 hours.
          </p>
        </div>

        {/* Earnings card */}
        <div style={{ background: 'var(--amber-bg)', border: '1px solid rgba(240,168,50,0.2)', padding: '1.25rem 2rem', width: '100%', maxWidth: 280 }}>
          <div style={{ fontSize: '0.65rem', fontWeight: 600, letterSpacing: '0.14em', textTransform: 'uppercase', color: 'var(--muted)', marginBottom: '0.35rem' }}>Pending earnings</div>
          <div style={{ fontFamily: 'var(--font-display)', fontSize: '2.5rem', fontWeight: 900, color: 'var(--amber)', lineHeight: 1 }}>₹{pay}</div>
          <div style={{ fontSize: '0.72rem', color: 'var(--muted)', marginTop: '0.3rem' }}>Added to balance on approval</div>
        </div>

        {/* Notification opt-in */}
        <div style={{ background: 'var(--s1)', border: '1px solid var(--border2)', padding: '0.85rem 1rem', width: '100%', display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
          <span style={{ fontSize: '1.1rem' }}>🔔</span>
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: '0.82rem', fontWeight: 600, color: 'var(--cream)', marginBottom: '0.15rem' }}>Get notified when approved</div>
            <div style={{ fontSize: '0.72rem', color: 'var(--muted)' }}>We'll ping you the moment it's done</div>
          </div>
          <button onClick={() => {}} style={{ background: 'var(--amber)', border: 'none', color: 'var(--bg)', fontFamily: 'var(--font-body)', fontSize: '0.7rem', fontWeight: 700, letterSpacing: '0.06em', textTransform: 'uppercase', padding: '0.4rem 0.75rem', cursor: 'pointer' }}>Enable</button>
        </div>

        {/* CTAs */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '0.6rem', width: '100%', maxWidth: 320 }}>
          <button className="btn btn-primary btn-full" onClick={() => setScreen('home')}>Back to Tasks →</button>
          <button className="btn btn-secondary btn-full" onClick={() => setScreen('earnings')}>View Earnings</button>
        </div>
      </div>
    </div>
  )
}

// ── EARNINGS ──────────────────────────────────────────────────────────────────
export function EarningsScreen({ active }: { active: boolean }) {
  const { balanceInr, pendingInr, transactions, setScreen, showToast } = useStore()

  const withdraw = (method: string) => showToast(`${method} withdrawal — live in production app`)

  return (
    <div className="screen" style={{ transform: active ? 'none' : 'translateX(-30%)', opacity: active ? 1 : 0, pointerEvents: active ? 'auto' : 'none', transition: 'all 0.3s' }}>
      <div className="top-bar">
        <span className="logo">cllctd<span>.</span></span>
      </div>

      <div className="scroll">
        {/* Balance card */}
        <div style={{ padding: '1.5rem 1.25rem', background: 'var(--s1)', borderBottom: '1px solid var(--border)' }}>
          <div style={{ fontFamily: 'var(--font-display)', fontSize: '0.68rem', fontWeight: 600, letterSpacing: '0.14em', textTransform: 'uppercase', color: 'var(--muted)', marginBottom: '0.4rem' }}>Available balance</div>
          <div style={{ fontFamily: 'var(--font-display)', fontSize: '3.2rem', fontWeight: 900, color: 'var(--amber)', lineHeight: 1, marginBottom: '0.35rem' }}>₹{balanceInr.toLocaleString('en-IN')}</div>
          <div style={{ fontSize: '0.78rem', color: 'var(--muted)' }}>+ <span style={{ color: 'var(--cream-d)', fontWeight: 600 }}>₹{pendingInr} pending</span> review</div>
        </div>

        {/* Withdraw row */}
        <div style={{ display: 'flex', gap: '1px', background: 'var(--border)' }}>
          {[
            { icon: '📲', label: 'UPI', sub: 'Instant' },
            { icon: '🏦', label: 'Bank', sub: 'Same day' },
            { icon: '₿', label: 'USDC', sub: 'Crypto' },
            { icon: '🎯', label: 'Points', sub: '1:1 rate' },
          ].map(w => (
            <button key={w.label} onClick={() => withdraw(w.label)} style={{
              flex: 1, padding: '0.85rem 0.25rem', background: 'var(--s1)', border: 'none',
              cursor: 'pointer', fontFamily: 'var(--font-body)', transition: 'background 0.15s',
              display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '0.25rem',
            }}
              onTouchStart={e => (e.currentTarget.style.background = 'var(--s2)')}
              onTouchEnd={e => (e.currentTarget.style.background = 'var(--s1)')}
            >
              <span style={{ fontSize: '1.2rem' }}>{w.icon}</span>
              <span style={{ fontSize: '0.7rem', fontWeight: 700, color: 'var(--amber)', letterSpacing: '0.06em', textTransform: 'uppercase' }}>{w.label}</span>
              <span style={{ fontSize: '0.62rem', color: 'var(--muted)' }}>{w.sub}</span>
            </button>
          ))}
        </div>

        {/* Referral */}
        <div style={{ background: 'var(--amber-bg)', borderTop: '1px solid rgba(240,168,50,0.12)', borderBottom: '1px solid rgba(240,168,50,0.12)', padding: '0.85rem 1.25rem', display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
          <span style={{ fontSize: '1.1rem' }}>👥</span>
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: '0.82rem', fontWeight: 600, color: 'var(--cream)' }}>Refer &amp; earn ₹100</div>
            <div style={{ fontSize: '0.72rem', color: 'var(--muted)' }}>Per approved contributor you refer</div>
          </div>
          <button onClick={() => showToast('Referral link copied!')} style={{ background: 'var(--amber)', border: 'none', color: 'var(--bg)', fontFamily: 'var(--font-body)', fontSize: '0.7rem', fontWeight: 700, letterSpacing: '0.06em', textTransform: 'uppercase', padding: '0.4rem 0.75rem', cursor: 'pointer' }}>Share</button>
        </div>

        {/* History */}
        <div className="sec-label">Transaction History</div>
        {transactions.map(tx => (
          <div key={tx.id} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '0.9rem 1.25rem', borderBottom: '1px solid var(--border)', background: 'var(--s1)' }}>
            <div>
              <div style={{ fontSize: '0.85rem', fontWeight: 500, color: 'var(--cream)', marginBottom: '0.15rem' }}>{tx.taskTitle}</div>
              <div style={{ fontSize: '0.72rem', color: 'var(--muted)' }}>{tx.date}</div>
            </div>
            <div style={{ textAlign: 'right' }}>
              <div style={{ fontSize: '0.9rem', fontWeight: 600, color: tx.amountInr < 0 ? 'var(--red)' : 'var(--green)', marginBottom: '0.2rem' }}>
                {tx.amountInr < 0 ? '' : '+'} ₹{Math.abs(tx.amountInr)}
              </div>
              <div style={{
                fontSize: '0.62rem', fontWeight: 700, letterSpacing: '0.06em', textTransform: 'uppercase',
                padding: '0.15rem 0.4rem',
                background: tx.status === 'pending' ? 'var(--amber-bg)' : tx.type === 'withdrawal' ? 'rgba(94,196,94,0.1)' : 'var(--green-bg)',
                color: tx.status === 'pending' ? 'var(--amber)' : 'var(--green)',
              }}>
                {tx.status === 'pending' ? 'Pending' : tx.type === 'withdrawal' ? 'Paid' : 'Approved'}
              </div>
            </div>
          </div>
        ))}
        <div style={{ height: '1rem' }} />
      </div>

      <nav className="bottom-nav">
        <button className="nav-btn" onClick={() => setScreen('home')}>
          <svg viewBox="0 0 24 24"><path d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" /></svg>
          <span>Tasks</span>
        </button>
        <button className="nav-btn active">
          <svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9" /><path d="M14.8 9A2 2 0 0013 8h-2a2 2 0 000 4h2a2 2 0 010 4h-2a2 2 0 01-1.8-1M12 7v1m0 8v1" /></svg>
          <span>Earnings</span>
        </button>
        <button className="nav-btn" onClick={() => setScreen('profile')}>
          <svg viewBox="0 0 24 24"><path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2" /><circle cx="12" cy="7" r="4" /></svg>
          <span>Profile</span>
        </button>
      </nav>
    </div>
  )
}

// ── PROFILE ───────────────────────────────────────────────────────────────────
export function ProfileScreen({ active }: { active: boolean }) {
  const { user, setScreen, showToast } = useStore()

  const badgeColors: Record<string, string> = { new: 'var(--muted)', good: 'var(--blue)', top: 'var(--amber)' }
  const badgeLabels: Record<string, string> = { new: 'New Contributor', good: 'Good Contributor', top: '⭐ Top Contributor' }

  return (
    <div className="screen" style={{ transform: active ? 'none' : 'translateX(-30%)', opacity: active ? 1 : 0, pointerEvents: active ? 'auto' : 'none', transition: 'all 0.3s' }}>
      <div className="top-bar">
        <span className="logo">cllctd<span>.</span></span>
      </div>

      <div className="scroll">
        {/* Profile header */}
        <div style={{ padding: '1.5rem 1.25rem 1rem', textAlign: 'center', borderBottom: '1px solid var(--border)' }}>
          <div style={{ width: 64, height: 64, borderRadius: '50%', background: 'var(--amber-bg)', border: '2px solid var(--amber)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '1.6rem', margin: '0 auto 0.75rem' }}>
            🙋‍♀️
          </div>
          <div style={{ fontFamily: 'var(--font-display)', fontSize: '1.3rem', fontWeight: 700, color: 'var(--cream)' }}>{user.name}</div>
          <div style={{ fontSize: '0.78rem', color: 'var(--muted)', margin: '0.2rem 0' }}>{user.languages.join(' · ')} · {user.phone}</div>
          <div style={{ display: 'flex', gap: '0.4rem', justifyContent: 'center', flexWrap: 'wrap', marginTop: '0.6rem' }}>
            <span style={{ fontSize: '0.65rem', fontWeight: 700, letterSpacing: '0.07em', textTransform: 'uppercase', padding: '0.2rem 0.6rem', background: 'var(--amber-bg)', color: 'var(--amber)', border: '1px solid rgba(240,168,50,0.2)' }}>
              {badgeLabels[user.badgeLevel]}
            </span>
            <span style={{ fontSize: '0.65rem', fontWeight: 700, letterSpacing: '0.07em', textTransform: 'uppercase', padding: '0.2rem 0.6rem', background: 'var(--s2)', color: 'var(--cream-d)' }}>Voice Verified</span>
            <span style={{ fontSize: '0.65rem', fontWeight: 700, letterSpacing: '0.07em', textTransform: 'uppercase', padding: '0.2rem 0.6rem', background: 'var(--s2)', color: 'var(--cream-d)' }}>KYC Done</span>
          </div>
        </div>

        {/* Stats */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '1px', background: 'var(--border)' }}>
          {[
            { val: '247', label: 'Tasks' },
            { val: '₹18,440', label: 'Total Earned' },
            { val: `${user.qualityScore}%`, label: 'Quality' },
          ].map(s => (
            <div key={s.label} style={{ background: 'var(--s1)', padding: '1rem', textAlign: 'center' }}>
              <div className="stat-val" style={{ fontSize: '1.2rem', marginBottom: '0.2rem' }}>{s.val}</div>
              <div style={{ fontSize: '0.62rem', color: 'var(--muted)', textTransform: 'uppercase', letterSpacing: '0.06em' }}>{s.label}</div>
            </div>
          ))}
        </div>

        {/* Quality bar */}
        <div style={{ padding: '1rem 1.25rem', background: 'var(--s1)', borderBottom: '1px solid var(--border)' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '0.5rem' }}>
            <span style={{ fontSize: '0.7rem', fontWeight: 600, letterSpacing: '0.07em', textTransform: 'uppercase', color: 'var(--cream-d)' }}>Quality Score</span>
            <span style={{ fontSize: '0.7rem', color: 'var(--green)', fontWeight: 600 }}>{user.qualityScore}% — Excellent</span>
          </div>
          <div className="prog-track" style={{ height: 6 }}><div className="prog-fill" style={{ width: `${user.qualityScore}%`, background: 'var(--green)' }} /></div>
        </div>

        {/* Account section */}
        <div className="sec-label">Account</div>
        {[
          { icon: '🌐', label: 'Languages', value: user.languages.join(', '), action: () => showToast('Language settings — edit in profile') },
          { icon: '📲', label: 'Payout Method', value: user.payoutUpi ? `UPI: ${user.payoutUpi}` : 'Not set', action: () => showToast('Payout settings — edit in profile') },
          { icon: '🪪', label: 'Identity Verification', value: 'Verified ✓', valueColor: 'var(--green)', action: () => showToast('Identity verified') },
          { icon: '👥', label: 'Refer & Earn', value: '₹100 per referral', valueColor: 'var(--amber)', action: () => showToast('Referral link copied!') },
        ].map(item => (
          <button key={item.label} onClick={item.action} style={{
            display: 'flex', alignItems: 'center', justifyContent: 'space-between',
            padding: '0.9rem 1.25rem', width: '100%',
            background: 'var(--s1)', border: 'none', borderBottom: '1px solid var(--border)',
            cursor: 'pointer', fontFamily: 'var(--font-body)', transition: 'background 0.15s',
          }}
            onTouchStart={e => (e.currentTarget.style.background = 'var(--s2)')}
            onTouchEnd={e => (e.currentTarget.style.background = 'var(--s1)')}
          >
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
              <span style={{ fontSize: '1rem', width: 24, textAlign: 'center' }}>{item.icon}</span>
              <span style={{ fontSize: '0.85rem', color: 'var(--cream)' }}>{item.label}</span>
            </div>
            <span style={{ fontSize: '0.75rem', color: item.valueColor || 'var(--muted)' }}>{item.value} →</span>
          </button>
        ))}

        {/* Data & privacy */}
        <div className="sec-label">Data &amp; Privacy</div>
        {[
          { icon: '🔒', label: 'My Data Rights', value: 'View' },
          { icon: '📄', label: 'Consent Records', value: 'Download' },
          { icon: '🗑️', label: 'Delete Account', value: '', danger: true },
        ].map(item => (
          <button key={item.label} onClick={() => showToast(`${item.label} — available in production app`)} style={{
            display: 'flex', alignItems: 'center', justifyContent: 'space-between',
            padding: '0.9rem 1.25rem', width: '100%',
            background: 'var(--s1)', border: 'none', borderBottom: '1px solid var(--border)',
            cursor: 'pointer', fontFamily: 'var(--font-body)',
          }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
              <span style={{ fontSize: '1rem', width: 24, textAlign: 'center' }}>{item.icon}</span>
              <span style={{ fontSize: '0.85rem', color: item.danger ? 'var(--red)' : 'var(--cream)' }}>{item.label}</span>
            </div>
            {item.value && <span style={{ fontSize: '0.75rem', color: 'var(--muted)' }}>{item.value} →</span>}
          </button>
        ))}

        <div style={{ height: '1rem' }} />
      </div>

      <nav className="bottom-nav">
        <button className="nav-btn" onClick={() => setScreen('home')}>
          <svg viewBox="0 0 24 24"><path d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" /></svg>
          <span>Tasks</span>
        </button>
        <button className="nav-btn" onClick={() => setScreen('earnings')}>
          <svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9" /><path d="M14.8 9A2 2 0 0013 8h-2a2 2 0 000 4h2a2 2 0 010 4h-2a2 2 0 01-1.8-1M12 7v1m0 8v1" /></svg>
          <span>Earnings</span>
        </button>
        <button className="nav-btn active">
          <svg viewBox="0 0 24 24"><path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2" /><circle cx="12" cy="7" r="4" /></svg>
          <span>Profile</span>
        </button>
      </nav>
    </div>
  )
}
