import { useStore } from '../store'
import type { Task } from '../types'

function TaskCard({ task }: { task: Task }) {
  const { setScreen, setActiveTask } = useStore()

  const open = () => {
    setActiveTask(task)
    setScreen('task-detail')
  }

  const typeColors: Record<string, string> = { voice: '#5ec45e', video: 'var(--blue)', photo: 'var(--amber)', text: 'var(--cream-d)' }

  return (
    <button onClick={open} style={{
      display: 'flex', alignItems: 'center', gap: '0.85rem',
      width: '100%', padding: '1rem 1.25rem',
      background: 'var(--s1)', borderBottom: '1px solid var(--border)',
      border: 'none', cursor: 'pointer', textAlign: 'left',
      fontFamily: 'var(--font-body)', transition: 'background 0.15s',
    }}
      onTouchStart={e => (e.currentTarget.style.background = 'var(--s2)')}
      onTouchEnd={e => (e.currentTarget.style.background = 'var(--s1)')}
    >
      {/* Icon */}
      <div style={{ width: 44, height: 44, background: 'var(--bg)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '1.3rem', flexShrink: 0 }}>
        {task.type === 'voice' ? '🎙️' : task.type === 'video' ? '🎬' : task.type === 'photo' ? '📷' : '📝'}
      </div>

      {/* Body */}
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontSize: '0.88rem', fontWeight: 600, color: 'var(--cream)', marginBottom: '0.2rem', display: 'flex', alignItems: 'center', flexWrap: 'wrap', gap: '0.2rem' }}>
          {task.title}
          {task.badge === 'hot' && <span className="badge badge-hot">Hot</span>}
          {task.badge === 'new' && <span className="badge badge-new">New</span>}
          {task.badge === 'bonus' && <span className="badge badge-bonus">2× bonus</span>}
        </div>
        <div style={{ fontSize: '0.73rem', color: 'var(--muted)', display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
          <span style={{ color: typeColors[task.type], fontWeight: 600, textTransform: 'uppercase', fontSize: '0.62rem', letterSpacing: '0.06em' }}>{task.type}</span>
          <span style={{ color: 'var(--border2)' }}>·</span>
          <span>{task.language}</span>
          <span style={{ color: 'var(--border2)' }}>·</span>
          <span>{task.itemCount} items</span>
        </div>
      </div>

      {/* Pay */}
      <div style={{ textAlign: 'right', flexShrink: 0 }}>
        <div className="stat-val" style={{ fontSize: '1.1rem' }}>₹{task.payInr}</div>
        <div style={{ fontSize: '0.68rem', color: 'var(--muted)', marginTop: '0.1rem' }}>~{task.estMinutes} min</div>
      </div>
    </button>
  )
}

export function HomeScreen({ active }: { active: boolean }) {
  const { tasks, taskFilter, setTaskFilter, user, todayEarnedInr, dailyGoalInr, setScreen } = useStore()

  const filters = ['all', 'voice', 'video', 'photo', 'text']
  const filtered = taskFilter === 'all' ? tasks : tasks.filter(t => t.type === taskFilter)
  const progress = Math.round((todayEarnedInr / dailyGoalInr) * 100)

  const greeting = () => {
    const h = new Date().getHours()
    if (h < 12) return 'Good morning'
    if (h < 17) return 'Good afternoon'
    return 'Good evening'
  }

  return (
    <div className="screen" style={{ transform: active ? 'none' : 'translateX(-30%)', opacity: active ? 1 : 0, pointerEvents: active ? 'auto' : 'none', transition: 'all 0.3s' }}>
      {/* Top bar */}
      <div className="top-bar">
        <span className="logo">cllctd<span>.</span></span>
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem' }}>
          <div className="pill">₹<span style={{ marginLeft: '0.15rem' }}>1,240</span></div>
          <button style={{ width: 32, height: 32, background: 'var(--s1)', border: '1px solid var(--border)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '0.9rem', cursor: 'pointer', position: 'relative' }}>
            🔔
            <span style={{ position: 'absolute', top: 6, right: 6, width: 6, height: 6, background: 'var(--amber)', borderRadius: '50%' }} />
          </button>
        </div>
      </div>

      <div className="scroll">
        {/* Greeting */}
        <div style={{ padding: '1.1rem 1.25rem 0.75rem' }}>
          <div style={{ fontSize: '0.72rem', color: 'var(--muted)', letterSpacing: '0.04em', marginBottom: '0.1rem' }}>{greeting()}</div>
          <div style={{ fontFamily: 'var(--font-display)', fontSize: '1.5rem', fontWeight: 700, color: 'var(--cream)', lineHeight: 1.1 }}>
            {user.name}, <em style={{ color: 'var(--amber)' }}>ready to earn?</em>
          </div>
        </div>

        {/* Stats row */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '1px', background: 'var(--border)', margin: '0 0 1px' }}>
          {[
            { val: '₹1,240', label: 'This Week' },
            { val: '18', label: 'Tasks Done' },
            { val: '91%', label: 'Approval' },
          ].map(s => (
            <div key={s.label} style={{ background: 'var(--s1)', padding: '0.9rem', textAlign: 'center' }}>
              <div className="stat-val" style={{ fontSize: '1.3rem', marginBottom: '0.2rem' }}>{s.val}</div>
              <div style={{ fontSize: '0.62rem', color: 'var(--muted)', textTransform: 'uppercase', letterSpacing: '0.06em' }}>{s.label}</div>
            </div>
          ))}
        </div>

        {/* Daily progress */}
        <div style={{ background: 'var(--s1)', padding: '0.9rem 1.25rem', borderBottom: '1px solid var(--border)' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '0.5rem' }}>
            <span style={{ fontSize: '0.7rem', fontWeight: 600, letterSpacing: '0.07em', textTransform: 'uppercase', color: 'var(--cream-d)' }}>Today's goal</span>
            <span style={{ fontSize: '0.7rem', color: 'var(--amber)', fontWeight: 600 }}>₹{todayEarnedInr} / ₹{dailyGoalInr}</span>
          </div>
          <div className="prog-track"><div className="prog-fill" style={{ width: `${progress}%` }} /></div>
        </div>

        {/* Demand banner */}
        <div style={{ background: 'var(--amber-bg)', borderBottom: '1px solid rgba(240,168,50,0.15)', borderTop: '1px solid rgba(240,168,50,0.1)', padding: '0.75rem 1.25rem', display: 'flex', alignItems: 'center', gap: '0.65rem' }}>
          <span style={{ width: 8, height: 8, background: 'var(--amber)', borderRadius: '50%', flexShrink: 0, animation: 'pulse 2s infinite' }} />
          <p style={{ fontSize: '0.78rem', color: 'var(--amber)', lineHeight: 1.5 }}>
            <strong>High demand right now:</strong> Tamil voice recordings — 2× bonus active
          </p>
        </div>

        {/* Filters */}
        <div style={{ display: 'flex', gap: '0.4rem', padding: '0.75rem 1.25rem', overflowX: 'auto', scrollbarWidth: 'none' }}>
          {filters.map(f => (
            <button key={f} onClick={() => setTaskFilter(f)} style={{
              padding: '0.4rem 0.9rem', whiteSpace: 'nowrap',
              background: taskFilter === f ? 'var(--amber-bg)' : 'var(--s1)',
              border: `1px solid ${taskFilter === f ? 'rgba(240,168,50,0.4)' : 'var(--border2)'}`,
              color: taskFilter === f ? 'var(--amber)' : 'var(--muted)',
              fontFamily: 'var(--font-body)', fontSize: '0.72rem', fontWeight: 600,
              letterSpacing: '0.07em', textTransform: 'uppercase', cursor: 'pointer',
              transition: 'all 0.15s',
            }}>
              {f === 'all' ? 'All Tasks' : f.charAt(0).toUpperCase() + f.slice(1)}
            </button>
          ))}
        </div>

        {/* Task list */}
        <div className="sec-label">Available Tasks</div>
        {filtered.length === 0 ? (
          <div style={{ padding: '2.5rem 1.5rem', textAlign: 'center', color: 'var(--muted)', fontSize: '0.85rem', lineHeight: 1.65 }}>
            No tasks for this category right now.<br />We'll notify you when new tasks appear.
          </div>
        ) : (
          filtered.map(t => <TaskCard key={t.id} task={t} />)
        )}

        <div style={{ height: '1rem' }} />
      </div>

      {/* Bottom nav */}
      <nav className="bottom-nav">
        <button className="nav-btn active">
          <svg viewBox="0 0 24 24"><path d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" /></svg>
          <span>Tasks</span>
        </button>
        <button className="nav-btn" onClick={() => setScreen('earnings')}>
          <svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9" /><path d="M14.8 9A2 2 0 0013 8h-2a2 2 0 000 4h2a2 2 0 010 4h-2a2 2 0 01-1.8-1M12 7v1m0 8v1" /></svg>
          <span>Earnings</span>
        </button>
        <button className="nav-btn" onClick={() => setScreen('profile')}>
          <svg viewBox="0 0 24 24"><path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2" /><circle cx="12" cy="7" r="4" /></svg>
          <span>Profile</span>
        </button>
      </nav>
    </div>
  )
}
