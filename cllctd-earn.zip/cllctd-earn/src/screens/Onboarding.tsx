import { useState, useRef } from 'react'
import { useStore } from '../store'

// ── SPLASH ────────────────────────────────────────────────────────────────────
export function SplashScreen() {
  const setScreen = useStore(s => s.setScreen)
  const [installing, setInstalling] = useState(false)

  return (
    <div className="screen" style={{ justifyContent: 'flex-end', padding: '0 0 2.5rem' }}>
      {/* Background grid */}
      <div style={{ position: 'absolute', inset: 0, backgroundImage: 'linear-gradient(var(--border) 1px,transparent 1px),linear-gradient(90deg,var(--border) 1px,transparent 1px)', backgroundSize: '60px 60px', opacity: 0.25 }} />
      <div style={{ position: 'absolute', top: '15%', left: '10%', width: 400, height: 400, background: 'radial-gradient(ellipse,rgba(240,168,50,0.07) 0%,transparent 70%)', pointerEvents: 'none' }} />

      <div style={{ position: 'relative', zIndex: 1, padding: '0 1.5rem' }}>
        {/* Logo */}
        <div style={{ marginBottom: '0.5rem', animation: 'fadeUp 0.5s ease both' }}>
          <span style={{ fontFamily: 'var(--font-display)', fontSize: '3.5rem', fontWeight: 900, color: 'var(--cream)' }}>cllctd</span>
          <span style={{ fontFamily: 'var(--font-display)', fontSize: '3.5rem', fontWeight: 900, color: 'var(--amber)' }}>.</span>
          <span style={{ fontFamily: 'var(--font-display)', fontSize: '3.5rem', fontWeight: 400, fontStyle: 'italic', color: 'var(--amber)' }}> earn</span>
        </div>
        <p style={{ fontSize: '1.1rem', color: 'var(--cream-d)', lineHeight: 1.7, maxWidth: 320, marginBottom: '2.5rem', animation: 'fadeUp 0.5s 0.1s ease both', opacity: 0, animationFillMode: 'forwards' }}>
          Your voice. Your environment.<br />Your daily life. <strong style={{ color: 'var(--cream)' }}>Your income.</strong>
        </p>

        {/* Benefit pills */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '0.6rem', marginBottom: '2.5rem', animation: 'fadeUp 0.5s 0.2s ease both', opacity: 0, animationFillMode: 'forwards' }}>
          {[
            { icon: '🎙️', label: 'Voice tasks', sub: '₹85–₹240 per task' },
            { icon: '🎬', label: 'Video tasks', sub: '₹120–₹200 per clip' },
            { icon: '📲', label: 'UPI payout', sub: 'Instant on approval' },
          ].map(b => (
            <div key={b.label} style={{ display: 'flex', alignItems: 'center', gap: '0.85rem', background: 'var(--s1)', padding: '0.9rem 1rem', borderLeft: '3px solid var(--amber)' }}>
              <span style={{ fontSize: '1.3rem', width: 28, textAlign: 'center' }}>{b.icon}</span>
              <div>
                <div style={{ fontSize: '0.88rem', fontWeight: 600, color: 'var(--cream)' }}>{b.label}</div>
                <div style={{ fontSize: '0.75rem', color: 'var(--muted)' }}>{b.sub}</div>
              </div>
            </div>
          ))}
        </div>

        {/* CTA */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem', animation: 'fadeUp 0.5s 0.3s ease both', opacity: 0, animationFillMode: 'forwards' }}>
          <button className="btn btn-primary btn-full" onClick={() => setScreen('phone')}>
            Get Started →
          </button>
          {!installing && (
            <button className="btn btn-ghost btn-full" onClick={() => setInstalling(true)} style={{ fontSize: '0.72rem', color: 'var(--muted)' }}>
              📲 Add to Home Screen for best experience
            </button>
          )}
          {installing && (
            <div style={{ background: 'var(--amber-bg)', border: '1px solid rgba(240,168,50,0.2)', padding: '0.85rem 1rem', fontSize: '0.8rem', color: 'var(--amber-d)', lineHeight: 1.6 }}>
              <strong>iPhone:</strong> tap Share → "Add to Home Screen"<br />
              <strong>Android:</strong> tap ⋮ → "Install app" or "Add to Home Screen"
            </div>
          )}
        </div>

        {/* Language toggle */}
        <div style={{ display: 'flex', gap: '0.5rem', marginTop: '1.25rem', animation: 'fadeUp 0.5s 0.35s ease both', opacity: 0, animationFillMode: 'forwards' }}>
          <button className="btn" style={{ background: 'var(--amber)', color: 'var(--bg)', padding: '0.4rem 0.9rem', fontSize: '0.72rem' }}>English</button>
          <button className="btn" style={{ background: 'var(--s2)', color: 'var(--muted)', padding: '0.4rem 0.9rem', fontSize: '0.72rem', border: '1px solid var(--border2)' }}>हिन्दी</button>
        </div>
      </div>
    </div>
  )
}

// ── PHONE ─────────────────────────────────────────────────────────────────────
export function PhoneScreen() {
  const { setScreen, setPhone } = useStore()
  const [num, setNum] = useState('')
  const [error, setError] = useState('')

  const submit = () => {
    if (num.replace(/\D/g, '').length < 10) { setError('Enter a valid 10-digit number'); return }
    setPhone('+91 ' + num)
    setScreen('otp')
  }

  return (
    <div className="screen">
      <div className="top-bar">
        <span className="logo">cllctd<span>.</span></span>
      </div>
      <div className="scroll" style={{ padding: '2.5rem 1.5rem' }}>
        <div style={{ marginBottom: '2rem' }}>
          <div style={{ fontSize: '0.68rem', fontWeight: 600, letterSpacing: '0.14em', textTransform: 'uppercase', color: 'var(--amber)', marginBottom: '0.75rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
            <span style={{ width: 20, height: 1, background: 'var(--amber)', display: 'inline-block' }} />
            Step 1 of 4
          </div>
          <h1 style={{ fontFamily: 'var(--font-display)', fontSize: '2rem', fontWeight: 700, color: 'var(--cream)', lineHeight: 1.05, marginBottom: '0.6rem' }}>
            Enter your<br /><em style={{ color: 'var(--amber)' }}>phone number.</em>
          </h1>
          <p style={{ fontSize: '0.88rem', color: 'var(--cream-d)', lineHeight: 1.7 }}>We'll send you a one-time code. No password needed.</p>
        </div>

        {/* Phone input */}
        <div style={{ display: 'flex', gap: '0', marginBottom: '1rem' }}>
          <div style={{ background: 'var(--s2)', border: '1px solid var(--border2)', borderRight: 'none', padding: '0.85rem 0.9rem', fontSize: '0.95rem', color: 'var(--cream-d)', flexShrink: 0, display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
            🇮🇳 +91
          </div>
          <input
            className="input"
            type="tel"
            inputMode="numeric"
            placeholder="98765 43210"
            value={num}
            onChange={e => { setNum(e.target.value); setError('') }}
            onKeyDown={e => e.key === 'Enter' && submit()}
            style={{ flex: 1 }}
            autoFocus
          />
        </div>
        {error && <p style={{ fontSize: '0.78rem', color: 'var(--red)', marginBottom: '1rem' }}>{error}</p>}

        <button className="btn btn-primary btn-full" onClick={submit} style={{ marginBottom: '1.5rem' }}>
          Send OTP →
        </button>

        {/* Consent */}
        <p style={{ fontSize: '0.74rem', color: 'var(--muted)', lineHeight: 1.65, textAlign: 'center' }}>
          By continuing you agree to cllctd's{' '}
          <span style={{ color: 'var(--amber)', cursor: 'pointer' }}>Terms of Service</span> and{' '}
          <span style={{ color: 'var(--amber)', cursor: 'pointer' }}>Data Use Policy.</span>{' '}
          We never share your number with third parties.
        </p>
      </div>
    </div>
  )
}

// ── OTP ───────────────────────────────────────────────────────────────────────
export function OtpScreen() {
  const { setScreen, setAuthed, phone } = useStore()
  const [digits, setDigits] = useState(['', '', '', '', '', ''])
  const [error, setError] = useState('')
  const [resendTimer, setResendTimer] = useState(45)
  const refs = Array.from({ length: 6 }, () => useRef<HTMLInputElement>(null))

  const handleDigit = (i: number, val: string) => {
    if (!/^\d*$/.test(val)) return
    const d = [...digits]
    d[i] = val.slice(-1)
    setDigits(d)
    setError('')
    if (val && i < 5) refs[i + 1].current?.focus()
    if (d.every(x => x !== '') && val) {
      setTimeout(() => verify(d.join('')), 100)
    }
  }

  const handleKeyDown = (i: number, e: React.KeyboardEvent) => {
    if (e.key === 'Backspace' && !digits[i] && i > 0) {
      refs[i - 1].current?.focus()
    }
  }

  const verify = (code: string) => {
    // Demo: any 6-digit code works
    if (code.length === 6) {
      setAuthed(true)
      setScreen('profile-setup')
    } else {
      setError('Incorrect code — please try again')
    }
  }

  return (
    <div className="screen">
      <div className="top-bar">
        <button className="btn-back" onClick={() => setScreen('phone')}>←</button>
        <span className="logo">cllctd<span>.</span></span>
        <div style={{ width: 36 }} />
      </div>
      <div className="scroll" style={{ padding: '2.5rem 1.5rem' }}>
        <div style={{ marginBottom: '2rem' }}>
          <div style={{ fontSize: '0.68rem', fontWeight: 600, letterSpacing: '0.14em', textTransform: 'uppercase', color: 'var(--amber)', marginBottom: '0.75rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
            <span style={{ width: 20, height: 1, background: 'var(--amber)', display: 'inline-block' }} />
            Step 2 of 4
          </div>
          <h1 style={{ fontFamily: 'var(--font-display)', fontSize: '2rem', fontWeight: 700, color: 'var(--cream)', marginBottom: '0.6rem', lineHeight: 1.1 }}>
            Enter the <em style={{ color: 'var(--amber)' }}>code.</em>
          </h1>
          <p style={{ fontSize: '0.88rem', color: 'var(--cream-d)' }}>Sent to {phone || '+91 ··· ···· ···'}</p>
        </div>

        {/* OTP boxes */}
        <div style={{ display: 'flex', gap: '0.6rem', marginBottom: '1.25rem' }}>
          {digits.map((d, i) => (
            <input
              key={i}
              ref={refs[i]}
              type="tel"
              inputMode="numeric"
              maxLength={1}
              value={d}
              onChange={e => handleDigit(i, e.target.value)}
              onKeyDown={e => handleKeyDown(i, e)}
              style={{
                flex: 1, textAlign: 'center', fontSize: '1.5rem', fontWeight: 700,
                padding: '0.85rem 0', background: 'var(--s1)',
                border: `1px solid ${d ? 'var(--amber)' : 'var(--border2)'}`,
                color: 'var(--cream)', outline: 'none', fontFamily: 'var(--font-body)'
              }}
              autoFocus={i === 0}
            />
          ))}
        </div>

        {error && <p style={{ fontSize: '0.78rem', color: 'var(--red)', marginBottom: '1rem' }}>{error}</p>}

        <button className="btn btn-primary btn-full" onClick={() => verify(digits.join(''))} style={{ marginBottom: '1rem' }}>
          Verify →
        </button>

        <p style={{ fontSize: '0.78rem', color: 'var(--muted)', textAlign: 'center' }}>
          Didn't receive it?{' '}
          {resendTimer > 0
            ? <span>Resend in {resendTimer}s</span>
            : <span style={{ color: 'var(--amber)', cursor: 'pointer' }} onClick={() => setResendTimer(45)}>Resend OTP</span>
          }
        </p>

        <div style={{ marginTop: '2rem', background: 'var(--amber-bg)', border: '1px solid rgba(240,168,50,0.15)', padding: '0.85rem', fontSize: '0.78rem', color: 'var(--amber)' }}>
          💡 <strong>Demo mode:</strong> enter any 6 digits to continue
        </div>
      </div>
    </div>
  )
}

// ── PROFILE SETUP ─────────────────────────────────────────────────────────────
export function ProfileSetupScreen() {
  const { setScreen, setUser } = useStore()
  const [name, setName] = useState('')
  const [lang, setLang] = useState('Hindi')
  const [prefs, setPrefs] = useState<string[]>(['voice'])
  const [error, setError] = useState('')

  const LANGUAGES = ['Hindi', 'Tamil', 'Telugu', 'Bengali', 'Marathi', 'Kannada', 'Gujarati', 'Malayalam', 'Punjabi', 'Odia', 'Other']
  const PREFS = [{ id: 'voice', icon: '🎙️', label: 'Voice' }, { id: 'video', icon: '🎬', label: 'Video' }, { id: 'photo', icon: '📷', label: 'Photos' }, { id: 'text', icon: '📝', label: 'Text' }]

  const toggle = (id: string) => setPrefs(p => p.includes(id) ? p.filter(x => x !== id) : [...p, id])

  const submit = () => {
    if (!name.trim()) { setError('Please enter your name'); return }
    setUser({ name: name.trim(), languages: [lang], taskPrefs: prefs as any[] })
    setScreen('payout-setup')
  }

  return (
    <div className="screen">
      <div className="top-bar">
        <button className="btn-back" onClick={() => setScreen('otp')}>←</button>
        <span className="logo">cllctd<span>.</span></span>
        <div style={{ width: 36 }} />
      </div>
      <div className="scroll" style={{ padding: '2rem 1.5rem' }}>
        <div style={{ marginBottom: '1.75rem' }}>
          <div style={{ fontSize: '0.68rem', fontWeight: 600, letterSpacing: '0.14em', textTransform: 'uppercase', color: 'var(--amber)', marginBottom: '0.75rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
            <span style={{ width: 20, height: 1, background: 'var(--amber)', display: 'inline-block' }} />
            Step 3 of 4
          </div>
          <h1 style={{ fontFamily: 'var(--font-display)', fontSize: '2rem', fontWeight: 700, color: 'var(--cream)', marginBottom: '0.5rem', lineHeight: 1.1 }}>
            Tell us about <em style={{ color: 'var(--amber)' }}>yourself.</em>
          </h1>
          <p style={{ fontSize: '0.85rem', color: 'var(--cream-d)' }}>We use this to show you the right tasks.</p>
        </div>

        {/* Name */}
        <div style={{ marginBottom: '1.25rem' }}>
          <label style={{ display: 'block', fontSize: '0.68rem', fontWeight: 600, letterSpacing: '0.1em', textTransform: 'uppercase', color: 'var(--muted)', marginBottom: '0.4rem' }}>Your first name</label>
          <input className="input" type="text" placeholder="e.g. Priya" value={name} onChange={e => { setName(e.target.value); setError('') }} autoFocus />
          {error && <p style={{ fontSize: '0.75rem', color: 'var(--red)', marginTop: '0.35rem' }}>{error}</p>}
        </div>

        {/* Language */}
        <div style={{ marginBottom: '1.25rem' }}>
          <label style={{ display: 'block', fontSize: '0.68rem', fontWeight: 600, letterSpacing: '0.1em', textTransform: 'uppercase', color: 'var(--muted)', marginBottom: '0.4rem' }}>Primary language for tasks</label>
          <select className="input" value={lang} onChange={e => setLang(e.target.value)} style={{ backgroundImage: 'none', cursor: 'pointer' }}>
            {LANGUAGES.map(l => <option key={l} value={l}>{l}</option>)}
          </select>
        </div>

        {/* Task prefs */}
        <div style={{ marginBottom: '2rem' }}>
          <label style={{ display: 'block', fontSize: '0.68rem', fontWeight: 600, letterSpacing: '0.1em', textTransform: 'uppercase', color: 'var(--muted)', marginBottom: '0.6rem' }}>Task preferences (select all that apply)</label>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.5rem' }}>
            {PREFS.map(p => (
              <button key={p.id} onClick={() => toggle(p.id)} style={{
                display: 'flex', alignItems: 'center', gap: '0.6rem',
                padding: '0.85rem 1rem',
                background: prefs.includes(p.id) ? 'var(--amber-bg)' : 'var(--s1)',
                border: `1px solid ${prefs.includes(p.id) ? 'rgba(240,168,50,0.4)' : 'var(--border2)'}`,
                color: prefs.includes(p.id) ? 'var(--amber)' : 'var(--cream-d)',
                cursor: 'pointer', fontFamily: 'var(--font-body)', fontSize: '0.85rem', fontWeight: 500,
                transition: 'all 0.15s',
              }}>
                <span>{p.icon}</span> {p.label}
                {prefs.includes(p.id) && <span style={{ marginLeft: 'auto', fontSize: '0.8rem' }}>✓</span>}
              </button>
            ))}
          </div>
        </div>

        <button className="btn btn-primary btn-full" onClick={submit}>Continue →</button>
      </div>
    </div>
  )
}

// ── PAYOUT SETUP ──────────────────────────────────────────────────────────────
export function PayoutSetupScreen() {
  const { setScreen, setUser, setAuthed } = useStore()
  const [method, setMethod] = useState<'upi' | 'bank' | 'usdc'>('upi')
  const [upi, setUpi] = useState('')
  const [ifsc, setIfsc] = useState('')
  const [account, setAccount] = useState('')
  const [usdc, setUsdc] = useState('')

  const complete = (skip = false) => {
    if (!skip && method === 'upi' && upi) setUser({ payoutUpi: upi })
    setAuthed(true)
    setScreen('home')
  }

  return (
    <div className="screen">
      <div className="top-bar">
        <button className="btn-back" onClick={() => setScreen('profile-setup')}>←</button>
        <span className="logo">cllctd<span>.</span></span>
        <button className="btn-ghost" onClick={() => complete(true)} style={{ fontSize: '0.72rem' }}>Skip</button>
      </div>
      <div className="scroll" style={{ padding: '2rem 1.5rem' }}>
        <div style={{ marginBottom: '1.75rem' }}>
          <div style={{ fontSize: '0.68rem', fontWeight: 600, letterSpacing: '0.14em', textTransform: 'uppercase', color: 'var(--amber)', marginBottom: '0.75rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
            <span style={{ width: 20, height: 1, background: 'var(--amber)', display: 'inline-block' }} />
            Step 4 of 4
          </div>
          <h1 style={{ fontFamily: 'var(--font-display)', fontSize: '2rem', fontWeight: 700, color: 'var(--cream)', marginBottom: '0.5rem', lineHeight: 1.1 }}>
            Set up <em style={{ color: 'var(--amber)' }}>your payout.</em>
          </h1>
          <p style={{ fontSize: '0.85rem', color: 'var(--cream-d)', lineHeight: 1.65 }}>Required before your first withdrawal. You can skip and add this later.</p>
        </div>

        {/* Method selector */}
        <div style={{ display: 'flex', gap: '0.5rem', marginBottom: '1.5rem' }}>
          {(['upi', 'bank', 'usdc'] as const).map(m => (
            <button key={m} onClick={() => setMethod(m)} style={{
              flex: 1, padding: '0.65rem 0',
              background: method === m ? 'var(--amber-bg)' : 'var(--s1)',
              border: `1px solid ${method === m ? 'rgba(240,168,50,0.4)' : 'var(--border2)'}`,
              color: method === m ? 'var(--amber)' : 'var(--muted)',
              fontFamily: 'var(--font-body)', fontSize: '0.75rem', fontWeight: 600,
              letterSpacing: '0.06em', textTransform: 'uppercase', cursor: 'pointer',
            }}>
              {m === 'upi' ? '📲 UPI' : m === 'bank' ? '🏦 Bank' : '₿ USDC'}
            </button>
          ))}
        </div>

        {method === 'upi' && (
          <div style={{ marginBottom: '1.25rem' }}>
            <label style={{ display: 'block', fontSize: '0.68rem', fontWeight: 600, letterSpacing: '0.1em', textTransform: 'uppercase', color: 'var(--muted)', marginBottom: '0.4rem' }}>UPI ID</label>
            <input className="input" type="text" placeholder="yourname@upi" value={upi} onChange={e => setUpi(e.target.value)} />
            <p style={{ fontSize: '0.72rem', color: 'var(--muted)', marginTop: '0.35rem' }}>Works with PhonePe, Google Pay, Paytm, BHIM</p>
          </div>
        )}
        {method === 'bank' && (
          <>
            <div style={{ marginBottom: '1rem' }}>
              <label style={{ display: 'block', fontSize: '0.68rem', fontWeight: 600, letterSpacing: '0.1em', textTransform: 'uppercase', color: 'var(--muted)', marginBottom: '0.4rem' }}>IFSC Code</label>
              <input className="input" type="text" placeholder="SBIN0001234" value={ifsc} onChange={e => setIfsc(e.target.value)} />
            </div>
            <div style={{ marginBottom: '1.25rem' }}>
              <label style={{ display: 'block', fontSize: '0.68rem', fontWeight: 600, letterSpacing: '0.1em', textTransform: 'uppercase', color: 'var(--muted)', marginBottom: '0.4rem' }}>Account Number</label>
              <input className="input" type="text" inputMode="numeric" placeholder="0000 0000 0000" value={account} onChange={e => setAccount(e.target.value)} />
            </div>
          </>
        )}
        {method === 'usdc' && (
          <div style={{ marginBottom: '1.25rem' }}>
            <label style={{ display: 'block', fontSize: '0.68rem', fontWeight: 600, letterSpacing: '0.1em', textTransform: 'uppercase', color: 'var(--muted)', marginBottom: '0.4rem' }}>USDC Wallet Address (Solana)</label>
            <input className="input" type="text" placeholder="Solana wallet address" value={usdc} onChange={e => setUsdc(e.target.value)} />
          </div>
        )}

        {/* Security note */}
        <div style={{ display: 'flex', gap: '0.6rem', background: 'var(--s1)', padding: '0.85rem', marginBottom: '1.5rem', borderLeft: '3px solid var(--border2)' }}>
          <span>🔒</span>
          <p style={{ fontSize: '0.75rem', color: 'var(--muted)', lineHeight: 1.6 }}>Your payout details are encrypted and never shared with buyers or third parties.</p>
        </div>

        <button className="btn btn-primary btn-full" onClick={() => complete(false)}>
          Start Earning →
        </button>
      </div>
    </div>
  )
}
