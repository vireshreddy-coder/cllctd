import { useState, useRef, useEffect, useCallback } from 'react'
import { useStore } from '../store'
import type { Task } from '../types'

// ── TASK DETAIL ───────────────────────────────────────────────────────────────
export function TaskDetailScreen() {
  const { activeTask, setScreen } = useStore()
  if (!activeTask) return null
  const t = activeTask

  const taskScreen: Record<string, string> = { voice: 'voice-task', video: 'video-task', photo: 'photo-task', text: 'text-task' }

  return (
    <div className="screen">
      <div className="top-bar">
        <button className="btn-back" onClick={() => setScreen('home')}>←</button>
        <span style={{ fontSize: '0.85rem', fontWeight: 600, color: 'var(--cream)', flex: 1, textAlign: 'center' }}>{t.title}</span>
        <span className="stat-val" style={{ fontSize: '1.1rem' }}>₹{t.payInr}</span>
      </div>

      <div className="scroll">
        {/* Hero */}
        <div style={{ padding: '1.5rem 1.25rem', background: 'var(--s1)', borderBottom: '1px solid var(--border)' }}>
          <span style={{ fontSize: '2.2rem', display: 'block', marginBottom: '0.75rem' }}>
            {t.type === 'voice' ? '🎙️' : t.type === 'video' ? '🎬' : t.type === 'photo' ? '📷' : '📝'}
          </span>
          <h2 style={{ fontFamily: 'var(--font-display)', fontSize: '1.5rem', fontWeight: 700, color: 'var(--cream)', marginBottom: '0.5rem', lineHeight: 1.1 }}>
            {t.title.split(' ').slice(0, -1).join(' ')}{' '}
            <em style={{ color: 'var(--amber)' }}>{t.title.split(' ').slice(-1)}</em>
          </h2>
          <p style={{ fontSize: '0.85rem', color: 'var(--cream-d)', lineHeight: 1.65 }}>
            {t.type === 'voice' && `Record yourself speaking ${t.itemCount} ${t.language} phrases. Natural voice — just speak clearly the way you normally would.`}
            {t.type === 'video' && `Film a ${t.estMinutes}-minute first-person clip of your hands at work. Any manual task counts.`}
            {t.type === 'photo' && `Upload ${t.itemCount} photos of outdoor scenes from your area. Markets, roads, public spaces.`}
            {t.type === 'text' && `Label ${t.itemCount} sentences as positive, negative, or neutral. Takes about ${t.estMinutes} minutes.`}
          </p>
        </div>

        {/* Meta row */}
        <div style={{ display: 'flex', gap: '1px', background: 'var(--border)' }}>
          {[
            { val: `~${t.estMinutes} min`, label: 'Est. time' },
            { val: String(t.itemCount), label: 'Items' },
            { val: '24h', label: 'Review time' },
          ].map(m => (
            <div key={m.label} style={{ flex: 1, background: 'var(--s1)', padding: '0.85rem', textAlign: 'center' }}>
              <div style={{ fontSize: '0.9rem', fontWeight: 600, color: 'var(--cream)' }}>{m.val}</div>
              <div style={{ fontSize: '0.62rem', color: 'var(--muted)', textTransform: 'uppercase', letterSpacing: '0.06em', marginTop: '0.15rem' }}>{m.label}</div>
            </div>
          ))}
        </div>

        {/* Instructions */}
        <div style={{ padding: '1.25rem' }}>
          <div className="sec-label" style={{ padding: 0, marginBottom: '0.75rem' }}>Instructions</div>
          {t.instructions.map((instr, i) => (
            <div key={i} style={{ display: 'flex', gap: '0.75rem', marginBottom: '0.7rem', alignItems: 'flex-start' }}>
              <div style={{ width: 22, height: 22, background: 'var(--amber-bg)', border: '1px solid rgba(240,168,50,0.25)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '0.65rem', fontWeight: 700, color: 'var(--amber)', flexShrink: 0, marginTop: '0.1rem' }}>
                {i + 1}
              </div>
              <p style={{ fontSize: '0.85rem', color: 'var(--cream-d)', lineHeight: 1.65 }}>{instr}</p>
            </div>
          ))}
        </div>

        {/* Consent disclosure */}
        <div style={{ margin: '0 1.25rem 1.5rem', background: 'var(--s1)', padding: '0.85rem', borderLeft: '3px solid var(--border2)', display: 'flex', gap: '0.6rem' }}>
          <span style={{ fontSize: '0.85rem' }}>🔒</span>
          <p style={{ fontSize: '0.75rem', color: 'var(--muted)', lineHeight: 1.6 }}>
            Your submission will be <strong style={{ color: 'var(--cream-d)' }}>anonymised</strong> and licensed to AI companies for model training. Full consent record generated on submission.
          </p>
        </div>

        <div style={{ padding: '0 1.25rem 1.5rem' }}>
          <button className="btn btn-primary btn-full" onClick={() => setScreen(taskScreen[t.type] as any)}>
            Start Task →
          </button>
        </div>
      </div>
    </div>
  )
}

// ── VOICE TASK ────────────────────────────────────────────────────────────────
export function VoiceTaskScreen() {
  const { activeTask, setScreen, addTransaction } = useStore()
  const [phraseIdx, setPhraseIdx] = useState(0)
  const [recording, setRecording] = useState(false)
  const [recorded, setRecorded] = useState<boolean[]>([])
  const [skips, setSkips] = useState(0)
  const [noiseWarning, setNoiseWarning] = useState(false)
  const recTimerRef = useRef<ReturnType<typeof setTimeout>>()
  const mediaRef = useRef<MediaRecorder | null>(null)
  const chunksRef = useRef<Blob[]>([])

  const t = activeTask
  const phrases = t?.phrases || []
  const total = phrases.length

  useEffect(() => { return () => { clearTimeout(recTimerRef.current) } }, [])

  const startRecording = useCallback(async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true })
      const mr = new MediaRecorder(stream)
      mediaRef.current = mr
      chunksRef.current = []
      mr.ondataavailable = e => chunksRef.current.push(e.data)
      mr.start()
      setRecording(true)
      // Auto-stop after 6s
      recTimerRef.current = setTimeout(() => stopRecording(), 6000)
    } catch {
      // Fallback for demo when mic not available
      setRecording(true)
      recTimerRef.current = setTimeout(() => stopRecordingDemo(), 3000)
    }
  }, [phraseIdx])

  const stopRecordingDemo = () => {
    setRecording(false)
    const next = [...recorded]
    next[phraseIdx] = true
    setRecorded(next)
    setTimeout(() => advance(true), 600)
  }

  const stopRecording = () => {
    clearTimeout(recTimerRef.current)
    if (mediaRef.current && mediaRef.current.state !== 'inactive') {
      mediaRef.current.stop()
      mediaRef.current.stream.getTracks().forEach(t => t.stop())
    }
    setRecording(false)
    const next = [...recorded]
    next[phraseIdx] = true
    setRecorded(next)
    setTimeout(() => advance(true), 600)
  }

  const toggleRec = () => recording ? stopRecording() : startRecording()

  const advance = (wasRecorded: boolean) => {
    if (!wasRecorded) setSkips(s => s + 1)
    if (phraseIdx + 1 >= total) {
      if (t) addTransaction({ id: Date.now().toString(), taskTitle: t.title, date: 'Just now', amountInr: t.payInr, status: 'pending', type: 'credit' })
      setScreen('submission-confirm')
    } else {
      setPhraseIdx(i => i + 1)
    }
  }

  if (!t || phrases.length === 0) return null

  const phrase = phrases[phraseIdx]

  return (
    <div className="screen" style={{ background: 'var(--bg)' }}>
      <div className="top-bar">
        <button className="btn-back" onClick={() => setScreen('task-detail')}>←</button>
        <span style={{ fontSize: '0.85rem', fontWeight: 600, color: 'var(--cream)', flex: 1, textAlign: 'center' }}>{t.language} Phrases</span>
        <span style={{ fontSize: '0.78rem', color: 'var(--muted)' }}>{phraseIdx + 1}/{total}</span>
      </div>

      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', padding: '1.5rem', gap: '1.5rem' }}>
        {/* Phrase card */}
        <div style={{ width: '100%', background: 'var(--s1)', border: '1px solid var(--border2)', padding: '1.5rem', textAlign: 'center' }}>
          <div style={{ fontSize: '0.65rem', fontWeight: 600, letterSpacing: '0.12em', textTransform: 'uppercase', color: 'var(--muted)', marginBottom: '0.6rem' }}>
            Phrase {phraseIdx + 1} of {total}
          </div>
          <div style={{ fontSize: '1.4rem', color: 'var(--cream)', fontWeight: 500, lineHeight: 1.5, marginBottom: '0.75rem' }}>{phrase.native}</div>
          <div style={{ fontSize: '0.85rem', color: 'var(--muted)', fontStyle: 'italic' }}>{phrase.roman}</div>
        </div>

        {/* Dot progress */}
        <div style={{ display: 'flex', gap: '0.4rem', justifyContent: 'center' }}>
          {phrases.map((_, i) => (
            <div key={i} style={{
              width: 8, height: 8, borderRadius: '50%',
              background: recorded[i] ? 'var(--green)' : i === phraseIdx ? 'var(--amber)' : 'var(--border2)',
              transition: 'background 0.3s',
            }} />
          ))}
        </div>

        {/* Waveform */}
        <div style={{ height: 44, display: 'flex', alignItems: 'center', gap: 3, justifyContent: 'center' }}>
          {recording ? (
            Array.from({ length: 7 }, (_, i) => (
              <div key={i} style={{ width: 3, background: 'var(--amber)', borderRadius: 2, transformOrigin: 'bottom', animation: `wave 0.6s ${i * 0.08}s ease-in-out infinite` }} style2={{height: [8,20,32,24,14,28,18][i]}} />
            )).map((bar, i) => (
              <div key={i} style={{ width: 3, background: 'var(--amber)', borderRadius: 2, transformOrigin: 'bottom', animation: `wave 0.6s ${i * 0.08}s ease-in-out infinite`, height: [8,20,32,24,14,28,18][i] }} />
            ))
          ) : (
            [8,14,6,18,10,14,8].map((h, i) => (
              <div key={i} style={{ width: 3, background: 'var(--border2)', borderRadius: 2, height: h }} />
            ))
          )}
        </div>

        {/* Record button */}
        <button onClick={toggleRec} style={{
          width: 72, height: 72, borderRadius: '50%',
          border: `3px solid var(--amber)`,
          background: recording ? 'var(--amber)' : 'transparent',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          cursor: 'pointer', fontSize: '1.6rem',
          animation: recording ? 'recPulse 1s ease-in-out infinite' : 'none',
          transition: 'background 0.2s',
        }}>
          {recording ? '⏹️' : '🎙️'}
        </button>

        <div style={{ fontSize: '0.78rem', color: 'var(--muted)', textAlign: 'center' }}>
          {recording ? '● Recording… tap to stop' : recorded[phraseIdx] ? '✓ Recorded — tap to re-record' : 'Tap to start recording'}
        </div>
      </div>

      <div style={{ padding: '1rem 1.25rem', borderTop: '1px solid var(--border)', flexShrink: 0 }}>
        <button className="btn btn-secondary btn-full" onClick={() => advance(false)} disabled={skips >= 2} style={{ opacity: skips >= 2 ? 0.4 : 1 }}>
          {skips >= 2 ? 'Max skips reached' : `Skip this phrase (${2 - skips} remaining)`}
        </button>
      </div>
    </div>
  )
}

// ── VIDEO TASK ────────────────────────────────────────────────────────────────
export function VideoTaskScreen() {
  const { activeTask, setScreen, addTransaction } = useStore()
  const [recording, setRecording] = useState(false)
  const [recorded, setRecorded] = useState(false)
  const [seconds, setSeconds] = useState(0)
  const timerRef = useRef<ReturnType<typeof setInterval>>()
  const videoRef = useRef<HTMLVideoElement>(null)
  const mediaRef = useRef<MediaRecorder | null>(null)
  const t = activeTask

  useEffect(() => { return () => { clearInterval(timerRef.current) } }, [])

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' }, audio: false })
      if (videoRef.current) { videoRef.current.srcObject = stream; videoRef.current.play() }
      const mr = new MediaRecorder(stream)
      mediaRef.current = mr
      mr.start()
      setRecording(true)
      setSeconds(0)
      timerRef.current = setInterval(() => setSeconds(s => { if (s >= 35) { stopRecording(); return s } return s + 1 }), 1000)
    } catch {
      setRecording(true)
      setSeconds(0)
      timerRef.current = setInterval(() => setSeconds(s => { if (s >= 8) { stopDemo(); return s } return s + 1 }), 1000)
    }
  }

  const stopDemo = () => { clearInterval(timerRef.current); setRecording(false); setRecorded(true) }
  const stopRecording = () => {
    clearInterval(timerRef.current)
    if (mediaRef.current && mediaRef.current.state !== 'inactive') { mediaRef.current.stop(); mediaRef.current.stream.getTracks().forEach(t => t.stop()) }
    setRecording(false); setRecorded(true)
  }

  const submit = () => {
    if (t) addTransaction({ id: Date.now().toString(), taskTitle: t.title, date: 'Just now', amountInr: t.payInr, status: 'pending', type: 'credit' })
    setScreen('submission-confirm')
  }

  if (!t) return null

  return (
    <div className="screen" style={{ background: '#000' }}>
      <div className="top-bar" style={{ background: 'rgba(0,0,0,0.8)', borderBottom: '1px solid rgba(255,255,255,0.1)' }}>
        <button className="btn-back" onClick={() => setScreen('task-detail')} style={{ background: 'rgba(255,255,255,0.1)', border: 'none', color: '#fff' }}>←</button>
        <span style={{ fontSize: '0.85rem', fontWeight: 600, color: '#fff', flex: 1, textAlign: 'center' }}>POV Clip</span>
        {recording && <span style={{ fontSize: '0.78rem', color: 'var(--red)', fontWeight: 600 }}>● {seconds}s</span>}
      </div>

      {/* Viewfinder */}
      <div style={{ flex: 1, position: 'relative', overflow: 'hidden', background: '#111' }}>
        <video ref={videoRef} autoPlay muted playsInline style={{ width: '100%', height: '100%', objectFit: 'cover' }} />

        {/* Overlay guide */}
        <div style={{ position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', pointerEvents: 'none' }}>
          <div style={{ border: '2px dashed rgba(240,168,50,0.5)', width: '70%', aspectRatio: '16/9', display: 'flex', alignItems: 'flex-end', justifyContent: 'center', paddingBottom: '0.5rem' }}>
            <span style={{ fontSize: '0.7rem', color: 'rgba(240,168,50,0.7)', background: 'rgba(0,0,0,0.5)', padding: '0.2rem 0.5rem' }}>Keep hands in frame</span>
          </div>
        </div>

        {/* Duration bar */}
        {recording && (
          <div style={{ position: 'absolute', bottom: 0, left: 0, right: 0 }}>
            <div style={{ height: 3, background: 'rgba(255,255,255,0.2)' }}>
              <div style={{ height: '100%', background: seconds < 25 ? 'var(--amber)' : 'var(--green)', width: `${(seconds / 35) * 100}%`, transition: 'width 1s linear' }} />
            </div>
          </div>
        )}

        {recorded && !recording && (
          <div style={{ position: 'absolute', inset: 0, background: 'rgba(0,0,0,0.6)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexDirection: 'column', gap: '0.5rem' }}>
            <span style={{ fontSize: '3rem' }}>✓</span>
            <span style={{ color: '#fff', fontWeight: 600 }}>Clip recorded — {seconds}s</span>
          </div>
        )}
      </div>

      <div style={{ padding: '1rem 1.25rem', display: 'flex', gap: '0.75rem', background: 'var(--bg)', borderTop: '1px solid var(--border)' }}>
        {!recorded ? (
          <button className="btn btn-primary btn-full" onClick={recording ? stopRecording : startRecording}
            style={{ background: recording ? 'var(--red)' : 'var(--amber)' }}>
            {recording ? `⏹  Stop (${seconds}s)` : '● Start Recording'}
          </button>
        ) : (
          <>
            <button className="btn btn-secondary" style={{ flex: 1 }} onClick={() => { setRecorded(false); setSeconds(0) }}>Re-record</button>
            <button className="btn btn-primary" style={{ flex: 2 }} onClick={submit}>Submit ₹{t.payInr} →</button>
          </>
        )}
      </div>

      {!recording && !recorded && (
        <div style={{ padding: '0.5rem 1.25rem 1rem', background: 'var(--bg)' }}>
          <p style={{ fontSize: '0.72rem', color: 'var(--muted)', textAlign: 'center' }}>Hold record for 25–35 seconds · Hands must be visible</p>
        </div>
      )}
    </div>
  )
}

// ── PHOTO TASK ────────────────────────────────────────────────────────────────
export function PhotoTaskScreen() {
  const { activeTask, setScreen, addTransaction } = useStore()
  const [photos, setPhotos] = useState<string[]>([])
  const [preview, setPreview] = useState<string | null>(null)
  const fileRef = useRef<HTMLInputElement>(null)
  const t = activeTask
  const required = t?.itemCount || 10

  const handleFiles = (files: FileList | null) => {
    if (!files) return
    const newPhotos: string[] = []
    Array.from(files).forEach(f => {
      if (photos.length + newPhotos.length >= required) return
      newPhotos.push(URL.createObjectURL(f))
    })
    setPhotos(p => [...p, ...newPhotos])
  }

  const remove = (i: number) => setPhotos(p => p.filter((_, idx) => idx !== i))

  const submit = () => {
    if (t) addTransaction({ id: Date.now().toString(), taskTitle: t.title, date: 'Just now', amountInr: t.payInr, status: 'pending', type: 'credit' })
    setScreen('submission-confirm')
  }

  if (!t) return null

  return (
    <div className="screen">
      <div className="top-bar">
        <button className="btn-back" onClick={() => setScreen('task-detail')}>←</button>
        <span style={{ fontSize: '0.85rem', fontWeight: 600, color: 'var(--cream)', flex: 1, textAlign: 'center' }}>Photo Upload</span>
        <span style={{ fontSize: '0.78rem', color: photos.length >= required ? 'var(--green)' : 'var(--muted)' }}>{photos.length}/{required}</span>
      </div>

      <div className="scroll">
        <div style={{ padding: '1rem 1.25rem 0.5rem' }}>
          <div className="prog-track"><div className="prog-fill" style={{ width: `${(photos.length / required) * 100}%`, background: photos.length >= required ? 'var(--green)' : 'var(--amber)' }} /></div>
          <p style={{ fontSize: '0.75rem', color: 'var(--muted)', marginTop: '0.4rem' }}>{required - photos.length > 0 ? `${required - photos.length} more photos needed` : '✓ All photos added — ready to submit'}</p>
        </div>

        {/* Add buttons */}
        {photos.length < required && (
          <div style={{ display: 'flex', gap: '0.5rem', padding: '0.75rem 1.25rem' }}>
            <button className="btn btn-primary" style={{ flex: 1 }} onClick={() => fileRef.current?.click()}>
              📷 Take Photo
            </button>
            <button className="btn btn-secondary" style={{ flex: 1 }} onClick={() => fileRef.current?.click()}>
              🖼️ Upload
            </button>
            <input ref={fileRef} type="file" accept="image/*" multiple capture="environment" style={{ display: 'none' }} onChange={e => handleFiles(e.target.files)} />
          </div>
        )}

        {/* Photo grid */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: '1px', background: 'var(--border)', margin: '0.5rem 0' }}>
          {photos.map((src, i) => (
            <div key={i} style={{ aspectRatio: '1', position: 'relative', overflow: 'hidden', background: 'var(--s2)' }}>
              <img src={src} style={{ width: '100%', height: '100%', objectFit: 'cover' }} onClick={() => setPreview(src)} />
              <button onClick={() => remove(i)} style={{ position: 'absolute', top: 4, right: 4, width: 20, height: 20, background: 'rgba(0,0,0,0.7)', border: 'none', color: '#fff', cursor: 'pointer', fontSize: '0.7rem', display: 'flex', alignItems: 'center', justifyContent: 'center', borderRadius: '50%' }}>×</button>
            </div>
          ))}
          {photos.length < required && Array.from({ length: Math.min(3, required - photos.length) }, (_, i) => (
            <div key={`empty-${i}`} style={{ aspectRatio: '1', background: 'var(--s1)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '1.5rem', color: 'var(--border2)', cursor: 'pointer' }} onClick={() => fileRef.current?.click()}>+</div>
          ))}
        </div>

        <div style={{ height: '1rem' }} />
      </div>

      <div style={{ padding: '1rem 1.25rem', borderTop: '1px solid var(--border)', flexShrink: 0 }}>
        <button className="btn btn-primary btn-full" onClick={submit} disabled={photos.length < required} style={{ opacity: photos.length < required ? 0.5 : 1 }}>
          {photos.length < required ? `Add ${required - photos.length} more photos` : `Submit — Earn ₹${t.payInr} →`}
        </button>
      </div>

      {/* Preview modal */}
      {preview && (
        <div style={{ position: 'absolute', inset: 0, background: 'rgba(0,0,0,0.92)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 100 }} onClick={() => setPreview(null)}>
          <img src={preview} style={{ maxWidth: '90%', maxHeight: '80%', objectFit: 'contain' }} />
        </div>
      )}
    </div>
  )
}

// ── TEXT TASK ─────────────────────────────────────────────────────────────────
const SENTENCES = [
  "The new smartphone model has excellent battery life.",
  "The service at the restaurant was very slow today.",
  "I'm not sure what to think about the recent news.",
  "The train arrived exactly on time, which was great.",
  "My commute was absolutely terrible this morning.",
  "The weather seems fine for this time of year.",
  "This product completely exceeded my expectations!",
  "The package arrived later than the estimated date.",
  "The movie had both good and bad moments throughout.",
  "Our local park is a wonderful place to relax.",
]

export function TextTaskScreen() {
  const { activeTask, setScreen, addTransaction } = useStore()
  const [idx, setIdx] = useState(0)
  const [answers, setAnswers] = useState<Record<number, string>>({})
  const t = activeTask
  const total = Math.min(SENTENCES.length, t?.itemCount || 10)

  const select = (label: string) => {
    setAnswers(a => ({ ...a, [idx]: label }))
    setTimeout(() => {
      if (idx + 1 >= total) {
        if (t) addTransaction({ id: Date.now().toString(), taskTitle: t.title, date: 'Just now', amountInr: t.payInr, status: 'pending', type: 'credit' })
        setScreen('submission-confirm')
      } else {
        setIdx(i => i + 1)
      }
    }, 350)
  }

  if (!t) return null

  const labels = ['Positive', 'Neutral', 'Negative']
  const labelColors: Record<string, string> = { Positive: 'var(--green)', Neutral: 'var(--amber)', Negative: 'var(--red)' }

  return (
    <div className="screen">
      <div className="top-bar">
        <button className="btn-back" onClick={() => setScreen('task-detail')}>←</button>
        <span style={{ fontSize: '0.85rem', fontWeight: 600, color: 'var(--cream)', flex: 1, textAlign: 'center' }}>Sentiment Labels</span>
        <span style={{ fontSize: '0.78rem', color: 'var(--muted)' }}>{idx + 1}/{total}</span>
      </div>

      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', padding: '1.5rem', gap: '1.5rem' }}>
        {/* Progress */}
        <div className="prog-track"><div className="prog-fill" style={{ width: `${((idx) / total) * 100}%` }} /></div>

        {/* Sentence */}
        <div style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <div style={{ background: 'var(--s1)', border: '1px solid var(--border2)', padding: '2rem 1.5rem', textAlign: 'center' }}>
            <div style={{ fontSize: '0.65rem', fontWeight: 600, letterSpacing: '0.12em', textTransform: 'uppercase', color: 'var(--muted)', marginBottom: '1rem' }}>
              Sentence {idx + 1}
            </div>
            <p style={{ fontSize: '1.1rem', color: 'var(--cream)', lineHeight: 1.65, fontStyle: 'italic' }}>
              "{SENTENCES[idx % SENTENCES.length]}"
            </p>
          </div>
        </div>

        {/* Label buttons */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '0.6rem' }}>
          <div style={{ fontSize: '0.68rem', fontWeight: 600, letterSpacing: '0.1em', textTransform: 'uppercase', color: 'var(--muted)', textAlign: 'center', marginBottom: '0.25rem' }}>
            What's the tone of this sentence?
          </div>
          {labels.map(label => (
            <button key={label} onClick={() => select(label)} style={{
              padding: '0.95rem', fontFamily: 'var(--font-body)', fontSize: '0.9rem', fontWeight: 600,
              background: answers[idx] === label ? labelColors[label] : 'var(--s1)',
              border: `1px solid ${answers[idx] === label ? labelColors[label] : 'var(--border2)'}`,
              color: answers[idx] === label ? (label === 'Neutral' ? 'var(--bg)' : 'var(--bg)') : 'var(--cream-d)',
              cursor: 'pointer', transition: 'all 0.15s', letterSpacing: '0.04em',
            }}>
              {label === 'Positive' ? '😊 ' : label === 'Neutral' ? '😐 ' : '😔 '}{label}
            </button>
          ))}
        </div>

        {/* Back/skip */}
        <div style={{ display: 'flex', gap: '0.5rem' }}>
          {idx > 0 && <button className="btn btn-ghost" style={{ flex: 1 }} onClick={() => setIdx(i => i - 1)}>← Back</button>}
          <button className="btn btn-ghost" style={{ flex: 1, color: 'var(--amber)' }} onClick={() => select('Neutral')}>Skip</button>
        </div>
      </div>
    </div>
  )
}
