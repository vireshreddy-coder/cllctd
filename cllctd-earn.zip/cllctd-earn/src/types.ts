export type Screen =
  | 'splash' | 'phone' | 'otp' | 'profile-setup' | 'payout-setup'
  | 'home' | 'task-detail' | 'voice-task' | 'video-task' | 'photo-task' | 'text-task'
  | 'submission-confirm' | 'earnings' | 'profile'

export type TaskType = 'voice' | 'video' | 'photo' | 'text'

export type BadgeLevel = 'new' | 'good' | 'top'

export type TransactionStatus = 'pending' | 'approved' | 'rejected'
export type TransactionType = 'credit' | 'withdrawal'

export interface Task {
  id: string
  title: string
  type: TaskType
  language: string
  languageCode: string
  payInr: number
  estMinutes: number
  itemCount: number
  instructions: string[]
  isBonus?: boolean
  bonusMultiplier?: number
  badge?: 'hot' | 'new' | 'bonus'
  phrases?: Phrase[]
}

export interface Phrase {
  native: string
  roman: string
}

export interface Transaction {
  id: string
  taskTitle: string
  date: string
  amountInr: number
  status: TransactionStatus
  type: TransactionType
}

export interface User {
  name: string
  phone: string
  languages: string[]
  taskPrefs: TaskType[]
  city?: string
  qualityScore: number
  badgeLevel: BadgeLevel
  payoutUpi?: string
  joinedDate: string
}
