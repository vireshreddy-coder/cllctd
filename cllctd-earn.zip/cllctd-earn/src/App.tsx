import { useStore } from './store'
import { SplashScreen, PhoneScreen, OtpScreen, ProfileSetupScreen, PayoutSetupScreen } from './screens/Onboarding'
import { HomeScreen } from './screens/Home'
import { TaskDetailScreen, VoiceTaskScreen, VideoTaskScreen, PhotoTaskScreen, TextTaskScreen } from './screens/Tasks'
import { SubmissionConfirmScreen, EarningsScreen, ProfileScreen } from './screens/CoreScreens'

const ONBOARDING: string[] = ['splash', 'phone', 'otp', 'profile-setup', 'payout-setup']
const TASK_SCREENS: string[] = ['task-detail', 'voice-task', 'video-task', 'photo-task', 'text-task', 'submission-confirm']

export default function App() {
  const { screen, toast } = useStore()

  const isOnboarding = ONBOARDING.includes(screen)
  const isTask = TASK_SCREENS.includes(screen)
  const isHome = screen === 'home'
  const isEarnings = screen === 'earnings'
  const isProfile = screen === 'profile'

  return (
    <div style={{ width: '100%', height: '100dvh', display: 'flex', justifyContent: 'center', alignItems: 'center', background: '#080706' }}>
      <div className="app">

        {/* ── Onboarding ── */}
        {screen === 'splash' && <SplashScreen />}
        {screen === 'phone' && <PhoneScreen />}
        {screen === 'otp' && <OtpScreen />}
        {screen === 'profile-setup' && <ProfileSetupScreen />}
        {screen === 'payout-setup' && <PayoutSetupScreen />}

        {/* ── Main tab screens (always mounted when authed, shown/hidden via CSS) ── */}
        {!isOnboarding && (
          <>
            <HomeScreen active={isHome} />
            <EarningsScreen active={isEarnings} />
            <ProfileScreen active={isProfile} />
          </>
        )}

        {/* ── Task flow screens (mounted on demand, slide in over tabs) ── */}
        {screen === 'task-detail' && <TaskDetailScreen />}
        {screen === 'voice-task' && <VoiceTaskScreen />}
        {screen === 'video-task' && <VideoTaskScreen />}
        {screen === 'photo-task' && <PhotoTaskScreen />}
        {screen === 'text-task' && <TextTaskScreen />}
        {screen === 'submission-confirm' && <SubmissionConfirmScreen />}

        {/* ── Toast ── */}
        <div className={`toast ${toast ? 'show' : ''}`}>{toast}</div>
      </div>
    </div>
  )
}
